import express from 'express'

const Router = express.Router()

const send = (req, res) =>
  res.send("ça fonctionne !")

Router.get('/', send)

export default Router
